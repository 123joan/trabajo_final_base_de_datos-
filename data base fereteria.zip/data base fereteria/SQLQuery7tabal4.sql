USE [ferreteriaPadre]
GO

/****** Object:  Table [dbo].[productos]    Script Date: 17/4/2023 11:38:14 p.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[productos](
	[ID] [int] NOT NULL,
	[nombre de producto] [varchar](50) NOT NULL,
	[provenecia] [varchar](50) NOT NULL,
	[numero de ventas] [nchar](10) NOT NULL,
	[precios] [nchar](10) NOT NULL,
	[personas que deben] [int] NOT NULL,
 CONSTRAINT [PK_productos] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


