USE [ferreteriaPadre]
GO

/****** Object:  Table [dbo].[deudores]    Script Date: 17/4/2023 11:35:54 p.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[deudores](
	[ID del deudor] [int] NOT NULL,
	[Nombre del deudor] [varchar](50) NOT NULL,
	[direcion del deudor] [varchar](50) NOT NULL,
	[cuanto debe el deudor] [int] NOT NULL,
	[ID de abministrativo a cargo] [int] NOT NULL,
	[cuotas a pagar] [varchar](50) NULL,
 CONSTRAINT [PK_deudores] PRIMARY KEY CLUSTERED 
(
	[ID del deudor] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


