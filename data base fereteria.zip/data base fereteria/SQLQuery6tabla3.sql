USE [ferreteriaPadre]
GO

/****** Object:  Table [dbo].[probeedores]    Script Date: 17/4/2023 11:37:55 p.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[probeedores](
	[ID suplidor] [int] NOT NULL,
	[ID de lo que suple] [int] NOT NULL,
	[nombre de lo que suple] [varchar](50) NOT NULL,
	[en cuanto vende este producto] [int] NOT NULL,
	[ID administrativo a cargo de ellos] [int] NOT NULL,
 CONSTRAINT [PK_probeedores] PRIMARY KEY CLUSTERED 
(
	[ID suplidor] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


