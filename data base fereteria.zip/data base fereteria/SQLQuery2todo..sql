create database ferreteriaPadre 

select * from [dbo].[deudores]